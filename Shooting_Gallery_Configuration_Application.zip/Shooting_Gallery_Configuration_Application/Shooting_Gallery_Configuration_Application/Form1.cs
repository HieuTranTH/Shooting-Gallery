﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;

namespace Shooting_Gallery_Configuration_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        int buttonToConfigure;
        int numberOfTargets;
        int highScoreDisplay;
        int timeLeftDisplay;
        int sound;

        

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void savePreset_Click(object sender, EventArgs e)
        {
            //check if all required fields filled out
            if ((buttonToConfigureValue.SelectedItem != null)
                && (numberOfTargetsValue.SelectedItem != null))
            {
                using(var sfd = new SaveFileDialog())
                {
                    sfd.Filter = "txt files (*.txt)|*.txt";
                    sfd.FilterIndex = 2;

                    if (sfd.ShowDialog() == DialogResult.OK)
                    {

                        //Parameter: Button to Configure
                        buttonToConfigure = buttonToConfigureValue.SelectedIndex + 1;

                        //Parameter: Number of Targets
                        numberOfTargets = numberOfTargetsValue.SelectedIndex + 1;

                        //Parameter: High Score Display
                        if (highScoreDisplayValue.Checked)
                            highScoreDisplay = 1;
                        else
                            highScoreDisplay = 0;

                        //Parameter: Time Left Display
                        if (timeLeftDisplayValue.Checked)
                            timeLeftDisplay = 1;
                        else
                            timeLeftDisplay = 0;

                        //Parameter: Sound
                        if (soundValue.Checked)
                            sound = 1;
                        else
                            sound = 0;

                        //Convert configuration parameters to strings
                        string[] configuration_parameters = { buttonToConfigure.ToString(),
                                                              lengthOfGameValue.Value.ToString(),
                                                              litBeforeHitValue.Value.ToString(),
                                                              litAfterHitValue.Value.ToString(),
                                                              numberOfTargets.ToString(),
                                                              pointsSmallTargetValue.Value.ToString(),
                                                              pointsMediumTargetValue.Value.ToString(),
                                                              pointsLargeTargetValue.Value.ToString(),
                                                              highScoreDisplay.ToString(),
                                                              timeLeftDisplay.ToString(),
                                                              sound.ToString()};

                        File.WriteAllLines(sfd.FileName, configuration_parameters);
                    }
                }

            }
            else
                MessageBox.Show("!!!Check Configuration Fields!!!\n(Make sure you have selected 'Button To Configure' and 'Number of Targets')");
        }



        private void loadPreset_Click(object sender, EventArgs e)
        {
            using (var sfd = new OpenFileDialog())
            {
                sfd.Filter = "txt files (*.txt)|*.txt";
                sfd.FilterIndex = 2;

                if (sfd.ShowDialog() == DialogResult.OK)
                {

                    string[] read_configuration_parameters = File.ReadAllLines(sfd.FileName);

                    buttonToConfigureValue.SelectedIndex = int.Parse(read_configuration_parameters[0]) - 1;

                    lengthOfGameValue.Value = int.Parse(read_configuration_parameters[1]);

                    litBeforeHitValue.Value = int.Parse(read_configuration_parameters[2]);

                    litAfterHitValue.Value = int.Parse(read_configuration_parameters[3]);

                    numberOfTargetsValue.SelectedIndex = int.Parse(read_configuration_parameters[4]) - 1;

                    pointsSmallTargetValue.Value = int.Parse(read_configuration_parameters[5]);

                    pointsMediumTargetValue.Value = int.Parse(read_configuration_parameters[6]);

                    pointsLargeTargetValue.Value = int.Parse(read_configuration_parameters[7]);


                    if ((int.Parse(read_configuration_parameters[8]) == 1))
                        highScoreDisplayValue.Checked = true;
                    else
                        highScoreDisplayValue.Checked = false;

                    if ((int.Parse(read_configuration_parameters[9]) == 1))
                        timeLeftDisplayValue.Checked = true;
                    else
                        timeLeftDisplayValue.Checked = false;

                    if ((int.Parse(read_configuration_parameters[10]) == 1))
                        soundValue.Checked = true;
                    else
                        soundValue.Checked = false;

                }
            }
        }
        


        private void upDownEnter(object sender, EventArgs e)
        {
            NumericUpDown answerBox = sender as NumericUpDown;

            if (answerBox != null)
            {
                int lengthOfAnswer = answerBox.Value.ToString().Length;
                answerBox.Select(0, lengthOfAnswer);
            }
        }

        private void sendConfiguration_Click(object sender, EventArgs e)
        {

            //Parameter: Button to Configure
            buttonToConfigure = buttonToConfigureValue.SelectedIndex + 1;

            //Parameter: Number of Targets
            numberOfTargets = numberOfTargetsValue.SelectedIndex + 1;

            //Parameter: High Score Display
            if (highScoreDisplayValue.Checked)
                highScoreDisplay = 1;
            else
                highScoreDisplay = 0;

            //Parameter: Time Left Display
            if (timeLeftDisplayValue.Checked)
                timeLeftDisplay = 1;
            else
                timeLeftDisplay = 0;

            //Parameter: Sound
            if (soundValue.Checked)
                sound = 1;
            else
                sound = 0;

            string[] configuration = new string[11];

            //fill the configuration with current parameters

            configuration[0] = buttonToConfigure.ToString();
            configuration[1] = lengthOfGameValue.Value.ToString();
            configuration[2] = litBeforeHitValue.Value.ToString();
            configuration[3] = litAfterHitValue.Value.ToString();
            configuration[4] = numberOfTargets.ToString();
            configuration[5] = pointsSmallTargetValue.Value.ToString();
            configuration[6] = pointsMediumTargetValue.Value.ToString();
            configuration[7] = pointsLargeTargetValue.Value.ToString();
            configuration[8] = highScoreDisplay.ToString();
            configuration[9] = timeLeftDisplay.ToString();
            configuration[10] = sound.ToString();


            if (PortList.Items.Count > 0)
            {
                serialPort1.PortName = PortList.Text;
            }

            if ((buttonToConfigureValue.SelectedItem != null)
                && (numberOfTargetsValue.SelectedItem != null)
                && (serialPort1.PortName != null))
            {
                

                serialPort1.Open();

                bool transmission_ok = true;
                int number_of_transmissions = 0;

                try
                {

                    while ((transmission_ok) && (number_of_transmissions < 11))
                    {
                        transmission_ok = send_parameter(configuration[number_of_transmissions]);
                        if (transmission_ok)
                            number_of_transmissions++;
                        else
                            MessageBox.Show("Data Not Successfully Sent", "Attention");
                    }                    
                    /*
                    serialPort1.Write(buttonToConfigure.ToString()+ "\n");
                    serialPort1.Write(lengthOfGameValue.Value.ToString()+ "\n");
                    serialPort1.Write(litBeforeHitValue.Value.ToString()+ "\n");
                    serialPort1.Write(litAfterHitValue.Value.ToString()+ "\n");
                    serialPort1.Write(numberOfTargets.ToString()+ "\n");
                    serialPort1.Write(pointsSmallTargetValue.Value.ToString()+ "\n");
                    serialPort1.Write(pointsMediumTargetValue.Value.ToString()+ "\n");
                    serialPort1.Write(pointsLargeTargetValue.Value.ToString()+ "\n");
                    serialPort1.Write(highScoreDisplay.ToString()+ "\n");
                    serialPort1.Write(timeLeftDisplay.ToString()+ "\n");
                    serialPort1.Write(sound.ToString()+ "\n");
                    */

                }

                catch (TimeoutException)
                { MessageBox.Show("Data Not Sent", "Attention"); }

                serialPort1.Close();

            }
            else
                MessageBox.Show("Could not send configuration due to:\n-No available COM port\n-All required configuration fields not filled","Attention");


        }

        private bool send_parameter(string parameter)
        {
            serialPort1.Write(parameter + "\n");
            if (serialPort1.ReadLine() == "ok")
            {
                return true;
            }
            else
                return false;
        }


        private void ListPorts_Click(object sender, EventArgs e)
        {
            PortList.Items.Clear();
            foreach (string s in SerialPort.GetPortNames())
            {
                PortList.Items.Add(s);
                PortList.Text = s;
            }

        }
    }
}
