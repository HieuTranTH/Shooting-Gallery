﻿namespace Shooting_Gallery_Configuration_Application
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.exit = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.numberOfTargetsValue = new System.Windows.Forms.ComboBox();
            this.buttonToConfigureValue = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timeLeftDisplayValue = new System.Windows.Forms.CheckBox();
            this.soundValue = new System.Windows.Forms.CheckBox();
            this.highScoreDisplayValue = new System.Windows.Forms.CheckBox();
            this.pointsLargeTargetValue = new System.Windows.Forms.NumericUpDown();
            this.pointsLargeTargetLabel = new System.Windows.Forms.Label();
            this.pointsMediumTargetValue = new System.Windows.Forms.NumericUpDown();
            this.pointsMediumTargetLabel = new System.Windows.Forms.Label();
            this.pointsSmallTargetValue = new System.Windows.Forms.NumericUpDown();
            this.pointsSmallTargetLabel = new System.Windows.Forms.Label();
            this.numberOfTargetsLabel = new System.Windows.Forms.Label();
            this.litAfterHitValue = new System.Windows.Forms.NumericUpDown();
            this.litAfterHitLabel = new System.Windows.Forms.Label();
            this.litBeforeHitValue = new System.Windows.Forms.NumericUpDown();
            this.lengthOfGameValue = new System.Windows.Forms.NumericUpDown();
            this.litBeforeHitLabel = new System.Windows.Forms.Label();
            this.lengthOfGameLabel = new System.Windows.Forms.Label();
            this.buttonToConfigureLabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.loadPreset = new System.Windows.Forms.Button();
            this.savePreset = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.ListPorts = new System.Windows.Forms.Button();
            this.PortList = new System.Windows.Forms.ComboBox();
            this.sendConfiguration = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pointsLargeTargetValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointsMediumTargetValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointsSmallTargetValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.litAfterHitValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.litBeforeHitValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lengthOfGameValue)).BeginInit();
            this.panel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // exit
            // 
            this.exit.Dock = System.Windows.Forms.DockStyle.Top;
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.Location = new System.Drawing.Point(0, 0);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(87, 46);
            this.exit.TabIndex = 16;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.2069F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 83.79311F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 83.62445F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.37555F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(580, 458);
            this.tableLayoutPanel1.TabIndex = 23;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.numberOfTargetsValue);
            this.panel1.Controls.Add(this.buttonToConfigureValue);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.timeLeftDisplayValue);
            this.panel1.Controls.Add(this.soundValue);
            this.panel1.Controls.Add(this.highScoreDisplayValue);
            this.panel1.Controls.Add(this.pointsLargeTargetValue);
            this.panel1.Controls.Add(this.pointsLargeTargetLabel);
            this.panel1.Controls.Add(this.pointsMediumTargetValue);
            this.panel1.Controls.Add(this.pointsMediumTargetLabel);
            this.panel1.Controls.Add(this.pointsSmallTargetValue);
            this.panel1.Controls.Add(this.pointsSmallTargetLabel);
            this.panel1.Controls.Add(this.numberOfTargetsLabel);
            this.panel1.Controls.Add(this.litAfterHitValue);
            this.panel1.Controls.Add(this.litAfterHitLabel);
            this.panel1.Controls.Add(this.litBeforeHitValue);
            this.panel1.Controls.Add(this.lengthOfGameValue);
            this.panel1.Controls.Add(this.litBeforeHitLabel);
            this.panel1.Controls.Add(this.lengthOfGameLabel);
            this.panel1.Controls.Add(this.buttonToConfigureLabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(97, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(480, 376);
            this.panel1.TabIndex = 3;
            // 
            // numberOfTargetsValue
            // 
            this.numberOfTargetsValue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.numberOfTargetsValue.FormattingEnabled = true;
            this.numberOfTargetsValue.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.numberOfTargetsValue.Location = new System.Drawing.Point(308, 132);
            this.numberOfTargetsValue.Name = "numberOfTargetsValue";
            this.numberOfTargetsValue.Size = new System.Drawing.Size(121, 21);
            this.numberOfTargetsValue.TabIndex = 5;
            // 
            // buttonToConfigureValue
            // 
            this.buttonToConfigureValue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.buttonToConfigureValue.FormattingEnabled = true;
            this.buttonToConfigureValue.Items.AddRange(new object[] {
            "Button 1",
            "Button 2",
            "Button 3",
            "Button 4"});
            this.buttonToConfigureValue.Location = new System.Drawing.Point(309, 12);
            this.buttonToConfigureValue.Name = "buttonToConfigureValue";
            this.buttonToConfigureValue.Size = new System.Drawing.Size(121, 21);
            this.buttonToConfigureValue.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 306);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(199, 30);
            this.label3.TabIndex = 47;
            this.label3.Text = "Sound";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 276);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(212, 30);
            this.label2.TabIndex = 46;
            this.label2.Text = "Time Left Display";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 246);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "High Score Display";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // timeLeftDisplayValue
            // 
            this.timeLeftDisplayValue.AutoSize = true;
            this.timeLeftDisplayValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeLeftDisplayValue.Location = new System.Drawing.Point(309, 285);
            this.timeLeftDisplayValue.Name = "timeLeftDisplayValue";
            this.timeLeftDisplayValue.Size = new System.Drawing.Size(31, 21);
            this.timeLeftDisplayValue.TabIndex = 10;
            this.timeLeftDisplayValue.Text = " ";
            this.timeLeftDisplayValue.UseVisualStyleBackColor = true;
            // 
            // soundValue
            // 
            this.soundValue.AutoSize = true;
            this.soundValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.soundValue.Location = new System.Drawing.Point(309, 315);
            this.soundValue.Name = "soundValue";
            this.soundValue.Size = new System.Drawing.Size(31, 21);
            this.soundValue.TabIndex = 11;
            this.soundValue.Text = " ";
            this.soundValue.UseVisualStyleBackColor = true;
            // 
            // highScoreDisplayValue
            // 
            this.highScoreDisplayValue.AutoSize = true;
            this.highScoreDisplayValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.highScoreDisplayValue.Location = new System.Drawing.Point(309, 255);
            this.highScoreDisplayValue.Name = "highScoreDisplayValue";
            this.highScoreDisplayValue.Size = new System.Drawing.Size(31, 21);
            this.highScoreDisplayValue.TabIndex = 9;
            this.highScoreDisplayValue.Text = " ";
            this.highScoreDisplayValue.UseVisualStyleBackColor = true;
            // 
            // pointsLargeTargetValue
            // 
            this.pointsLargeTargetValue.Location = new System.Drawing.Point(309, 223);
            this.pointsLargeTargetValue.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.pointsLargeTargetValue.Name = "pointsLargeTargetValue";
            this.pointsLargeTargetValue.Size = new System.Drawing.Size(120, 20);
            this.pointsLargeTargetValue.TabIndex = 8;
            this.pointsLargeTargetValue.Enter += new System.EventHandler(this.upDownEnter);
            // 
            // pointsLargeTargetLabel
            // 
            this.pointsLargeTargetLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pointsLargeTargetLabel.Location = new System.Drawing.Point(3, 216);
            this.pointsLargeTargetLabel.Name = "pointsLargeTargetLabel";
            this.pointsLargeTargetLabel.Size = new System.Drawing.Size(300, 30);
            this.pointsLargeTargetLabel.TabIndex = 37;
            this.pointsLargeTargetLabel.Text = "Large Target Points";
            this.pointsLargeTargetLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pointsMediumTargetValue
            // 
            this.pointsMediumTargetValue.Location = new System.Drawing.Point(309, 193);
            this.pointsMediumTargetValue.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.pointsMediumTargetValue.Name = "pointsMediumTargetValue";
            this.pointsMediumTargetValue.Size = new System.Drawing.Size(120, 20);
            this.pointsMediumTargetValue.TabIndex = 7;
            this.pointsMediumTargetValue.Enter += new System.EventHandler(this.upDownEnter);
            // 
            // pointsMediumTargetLabel
            // 
            this.pointsMediumTargetLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pointsMediumTargetLabel.Location = new System.Drawing.Point(3, 186);
            this.pointsMediumTargetLabel.Name = "pointsMediumTargetLabel";
            this.pointsMediumTargetLabel.Size = new System.Drawing.Size(300, 30);
            this.pointsMediumTargetLabel.TabIndex = 35;
            this.pointsMediumTargetLabel.Text = "Medium Target Points";
            this.pointsMediumTargetLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pointsSmallTargetValue
            // 
            this.pointsSmallTargetValue.Location = new System.Drawing.Point(309, 163);
            this.pointsSmallTargetValue.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.pointsSmallTargetValue.Name = "pointsSmallTargetValue";
            this.pointsSmallTargetValue.Size = new System.Drawing.Size(120, 20);
            this.pointsSmallTargetValue.TabIndex = 6;
            this.pointsSmallTargetValue.Enter += new System.EventHandler(this.upDownEnter);
            // 
            // pointsSmallTargetLabel
            // 
            this.pointsSmallTargetLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pointsSmallTargetLabel.Location = new System.Drawing.Point(3, 156);
            this.pointsSmallTargetLabel.Name = "pointsSmallTargetLabel";
            this.pointsSmallTargetLabel.Size = new System.Drawing.Size(300, 30);
            this.pointsSmallTargetLabel.TabIndex = 33;
            this.pointsSmallTargetLabel.Text = "Small Target Points";
            this.pointsSmallTargetLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numberOfTargetsLabel
            // 
            this.numberOfTargetsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberOfTargetsLabel.Location = new System.Drawing.Point(3, 126);
            this.numberOfTargetsLabel.Name = "numberOfTargetsLabel";
            this.numberOfTargetsLabel.Size = new System.Drawing.Size(300, 30);
            this.numberOfTargetsLabel.TabIndex = 31;
            this.numberOfTargetsLabel.Text = "Number of Targets";
            this.numberOfTargetsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // litAfterHitValue
            // 
            this.litAfterHitValue.Location = new System.Drawing.Point(309, 103);
            this.litAfterHitValue.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.litAfterHitValue.Name = "litAfterHitValue";
            this.litAfterHitValue.Size = new System.Drawing.Size(120, 20);
            this.litAfterHitValue.TabIndex = 4;
            this.litAfterHitValue.Enter += new System.EventHandler(this.upDownEnter);
            // 
            // litAfterHitLabel
            // 
            this.litAfterHitLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.litAfterHitLabel.Location = new System.Drawing.Point(3, 96);
            this.litAfterHitLabel.Name = "litAfterHitLabel";
            this.litAfterHitLabel.Size = new System.Drawing.Size(300, 30);
            this.litAfterHitLabel.TabIndex = 29;
            this.litAfterHitLabel.Text = "Time Target is Lit After a hit (seconds)";
            this.litAfterHitLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // litBeforeHitValue
            // 
            this.litBeforeHitValue.Location = new System.Drawing.Point(309, 73);
            this.litBeforeHitValue.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.litBeforeHitValue.Name = "litBeforeHitValue";
            this.litBeforeHitValue.Size = new System.Drawing.Size(120, 20);
            this.litBeforeHitValue.TabIndex = 3;
            this.litBeforeHitValue.Enter += new System.EventHandler(this.upDownEnter);
            // 
            // lengthOfGameValue
            // 
            this.lengthOfGameValue.Location = new System.Drawing.Point(309, 43);
            this.lengthOfGameValue.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.lengthOfGameValue.Name = "lengthOfGameValue";
            this.lengthOfGameValue.Size = new System.Drawing.Size(120, 20);
            this.lengthOfGameValue.TabIndex = 2;
            this.lengthOfGameValue.Enter += new System.EventHandler(this.upDownEnter);
            // 
            // litBeforeHitLabel
            // 
            this.litBeforeHitLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.litBeforeHitLabel.Location = new System.Drawing.Point(3, 66);
            this.litBeforeHitLabel.Name = "litBeforeHitLabel";
            this.litBeforeHitLabel.Size = new System.Drawing.Size(300, 30);
            this.litBeforeHitLabel.TabIndex = 25;
            this.litBeforeHitLabel.Text = "Time Target is Lit Before a hit (seconds)";
            this.litBeforeHitLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lengthOfGameLabel
            // 
            this.lengthOfGameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lengthOfGameLabel.Location = new System.Drawing.Point(3, 36);
            this.lengthOfGameLabel.Name = "lengthOfGameLabel";
            this.lengthOfGameLabel.Size = new System.Drawing.Size(300, 30);
            this.lengthOfGameLabel.TabIndex = 24;
            this.lengthOfGameLabel.Text = "Length of Game (seconds)";
            this.lengthOfGameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // buttonToConfigureLabel
            // 
            this.buttonToConfigureLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonToConfigureLabel.Location = new System.Drawing.Point(3, 6);
            this.buttonToConfigureLabel.Name = "buttonToConfigureLabel";
            this.buttonToConfigureLabel.Size = new System.Drawing.Size(300, 30);
            this.buttonToConfigureLabel.TabIndex = 23;
            this.buttonToConfigureLabel.Text = "Button To Configure";
            this.buttonToConfigureLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.exit);
            this.panel2.Location = new System.Drawing.Point(3, 385);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(87, 70);
            this.panel2.TabIndex = 15;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.loadPreset);
            this.flowLayoutPanel1.Controls.Add(this.savePreset);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(97, 385);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.flowLayoutPanel1.Size = new System.Drawing.Size(480, 70);
            this.flowLayoutPanel1.TabIndex = 5;
            // 
            // loadPreset
            // 
            this.loadPreset.AutoSize = true;
            this.loadPreset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadPreset.Location = new System.Drawing.Point(323, 3);
            this.loadPreset.Name = "loadPreset";
            this.loadPreset.Size = new System.Drawing.Size(154, 46);
            this.loadPreset.TabIndex = 13;
            this.loadPreset.Text = "Load Configuration";
            this.loadPreset.UseVisualStyleBackColor = true;
            this.loadPreset.Click += new System.EventHandler(this.loadPreset_Click);
            // 
            // savePreset
            // 
            this.savePreset.AutoSize = true;
            this.savePreset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savePreset.Location = new System.Drawing.Point(163, 3);
            this.savePreset.Name = "savePreset";
            this.savePreset.Size = new System.Drawing.Size(154, 46);
            this.savePreset.TabIndex = 12;
            this.savePreset.Text = "Save Configuration";
            this.savePreset.UseVisualStyleBackColor = true;
            this.savePreset.Click += new System.EventHandler(this.savePreset_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.flowLayoutPanel2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(88, 376);
            this.panel3.TabIndex = 16;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.ListPorts);
            this.flowLayoutPanel2.Controls.Add(this.PortList);
            this.flowLayoutPanel2.Controls.Add(this.sendConfiguration);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(88, 376);
            this.flowLayoutPanel2.TabIndex = 0;
            // 
            // ListPorts
            // 
            this.ListPorts.Location = new System.Drawing.Point(3, 3);
            this.ListPorts.Name = "ListPorts";
            this.ListPorts.Size = new System.Drawing.Size(79, 23);
            this.ListPorts.TabIndex = 1;
            this.ListPorts.Text = "List ports";
            this.ListPorts.UseVisualStyleBackColor = true;
            this.ListPorts.Click += new System.EventHandler(this.ListPorts_Click);
            // 
            // PortList
            // 
            this.PortList.FormattingEnabled = true;
            this.PortList.Location = new System.Drawing.Point(3, 32);
            this.PortList.Name = "PortList";
            this.PortList.Size = new System.Drawing.Size(79, 21);
            this.PortList.TabIndex = 4;
            // 
            // sendConfiguration
            // 
            this.sendConfiguration.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendConfiguration.Location = new System.Drawing.Point(3, 59);
            this.sendConfiguration.Name = "sendConfiguration";
            this.sendConfiguration.Size = new System.Drawing.Size(79, 34);
            this.sendConfiguration.TabIndex = 14;
            this.sendConfiguration.Text = "Send Configuration";
            this.sendConfiguration.UseVisualStyleBackColor = true;
            this.sendConfiguration.Click += new System.EventHandler(this.sendConfiguration_Click);
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.Handshake = System.IO.Ports.Handshake.XOnXOff;
            this.serialPort1.ReadTimeout = 10000;
            this.serialPort1.WriteTimeout = 100;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 435);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Shooting Gallery Configuration Application";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pointsLargeTargetValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointsMediumTargetValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pointsSmallTargetValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.litAfterHitValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.litBeforeHitValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lengthOfGameValue)).EndInit();
            this.panel2.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label numberOfTargetsLabel;
        private System.Windows.Forms.NumericUpDown litAfterHitValue;
        private System.Windows.Forms.Label litAfterHitLabel;
        private System.Windows.Forms.NumericUpDown litBeforeHitValue;
        private System.Windows.Forms.NumericUpDown lengthOfGameValue;
        private System.Windows.Forms.Label litBeforeHitLabel;
        private System.Windows.Forms.Label lengthOfGameLabel;
        private System.Windows.Forms.Label buttonToConfigureLabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button loadPreset;
        private System.Windows.Forms.Button savePreset;
        private System.Windows.Forms.CheckBox timeLeftDisplayValue;
        private System.Windows.Forms.CheckBox soundValue;
        private System.Windows.Forms.CheckBox highScoreDisplayValue;
        private System.Windows.Forms.NumericUpDown pointsLargeTargetValue;
        private System.Windows.Forms.Label pointsLargeTargetLabel;
        private System.Windows.Forms.NumericUpDown pointsMediumTargetValue;
        private System.Windows.Forms.Label pointsMediumTargetLabel;
        private System.Windows.Forms.NumericUpDown pointsSmallTargetValue;
        private System.Windows.Forms.Label pointsSmallTargetLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox buttonToConfigureValue;
        private System.Windows.Forms.ComboBox numberOfTargetsValue;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button sendConfiguration;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button ListPorts;
        private System.Windows.Forms.ComboBox PortList;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
    }
}

